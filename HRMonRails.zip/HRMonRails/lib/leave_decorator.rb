class BasicLeave
    def  initialize(noofleave)
        @noofleave=noofleave
    end
    def noofleave
        return @noofleave
    end
end

class LeaveDecorator
    def initialize(real_leave)
        @real_leave = real_leave
        @extra_noofleave = 0
    end
    def noofleave
        return @extra_noofleave+@real_leave.noofleave
    end
end

class PermanentEmployeeLeaveDecorator < LeaveDecorator
	def initialize(real_leave)
		super(real_leave)
		@extra_noofleave = 20
	end
end


class TemporaryEmployeeLeaveDecorator < LeaveDecorator
	def initialize(real_leave)
		super(real_leave)
		@extra_noofleave = 10
	end
end