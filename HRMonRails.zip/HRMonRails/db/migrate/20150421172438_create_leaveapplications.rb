class CreateLeaveapplications < ActiveRecord::Migration
  def change
    create_table :leaveapplications do |t|
     t.datetime :Fromdate
      t.datetime :Todate
      t.string :Description
      t.integer :status
      t.references :Leavetype, index: true
      t.references :Employee , index: true

      t.timestamps null: false
    end
    add_foreign_key :leaveapplications, :leavetypes
  end
end
