class CreateLeavetype < ActiveRecord::Migration
  def change
    create_table :leavetypes do |t|
       t.string :description
       t.timestamps null: false
    end
  end
end
