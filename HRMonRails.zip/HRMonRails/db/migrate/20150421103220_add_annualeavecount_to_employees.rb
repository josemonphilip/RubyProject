class AddAnnualeavecountToEmployees < ActiveRecord::Migration
  def change
    add_column "employees","annualeavecount",:integer
  end
end
