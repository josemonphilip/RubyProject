class AddEmploymenttypeToEmployees < ActiveRecord::Migration
  def change
    add_column "employees","employmenttype",:integer
  end
end
