class CreateEmployees < ActiveRecord::Migration
  def change
    create_table :employees do |t|
      t.string :name
      t.string :address
      t.datetime :DOB
      t.references :department, index: true

      t.timestamps null: false
    end
    add_foreign_key :employees, :departments
  end
end
