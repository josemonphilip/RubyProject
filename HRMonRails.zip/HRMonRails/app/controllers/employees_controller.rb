class EmployeesController < ApplicationController
  layout "admin"
  require 'leave_decorator'

  before_action :confirm_logged_in, :set_employee, only: [:show, :edit, :update, :destroy]

  # GET /employees
  # GET /employees.json
  def index
    if params[:search]
      @employees = Employee.search(params[:search])
    else
      @employees= Employee.all
    end
  end

  # GET /employees/1
  # GET /employees/1.json
  def show
  end

  # GET /employees/new
  def new
    @departments=Department.all
    @employee = Employee.new
  end

  # GET /employees/1/edit
  def edit
     @departments=Department.all
  end

  # POST /employees
  # POST /employees.json
  def create
    #useing decorator patten
    #cloning the parameter
     attributes = employee_params.clone
     #creating base fom decorator
     leave=BasicLeave.new(0)
     #checking permanent or temporary
    if attributes[:employmenttype].to_f==0
      leave=PermanentEmployeeLeaveDecorator.new(leave)
    else
      leave=TemporaryEmployeeLeaveDecorator.new(leave)
    end
    #now adding to leva count
    attributes[:annualeavecount]=leave.noofleave
    
    @employee = Employee.new(attributes)

    respond_to do |format|
      if @employee.save
        format.html { redirect_to @employee, notice: 'Employee was successfully created.' }
        format.json { render :show, status: :created, location: @employee }
      else
        format.html { render :new }
        format.json { render json: @employee.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /employees/1
  # PATCH/PUT /employees/1.json
  def update
    #implimenting decorator pattern
    attributes = employee_params.clone
  
    leave=BasicLeave.new(0)
    if attributes[:employmenttype].to_f==0
      leave=PermanentEmployeeLeaveDecorator.new(leave)
    else
      leave=TemporaryEmployeeLeaveDecorator.new(leave)
    end
    attributes[:annualeavecount]=leave.noofleave
    
    respond_to do |format|
      if @employee.update(attributes)
        format.html { redirect_to @employee, notice: 'Employee was successfully updated.' }
        format.json { render :show, status: :ok, location: @employee }
      else
        format.html { render :edit }
        format.json { render json: @employee.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /employees/1
  # DELETE /employees/1.json
  def destroy
    @employee.destroy
    respond_to do |format|
      format.html { redirect_to employees_url, notice: 'Employee was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_employee
      @employee = Employee.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def employee_params
      params.require(:employee).permit(:name, :address, :DOB, :department_id,:employmenttype,:annualeavecount)
    end
end
