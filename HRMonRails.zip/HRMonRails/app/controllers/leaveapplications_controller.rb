class LeaveapplicationsController < ApplicationController
  before_action :confirm_logged_in, :set_leaveapplication, only: [:show, :edit, :update, :destroy]

  # GET /leaveapplications
  # GET /leaveapplications.json
  def index
    eid=Integer(session[:employee_id])
    @leaveapplications = Leaveapplication.where("\"Employee_id\" =?",eid)
  end

  # GET /leaveapplications/1
  # GET /leaveapplications/1.json
  def show
  end

  # GET /leaveapplications/new
  def new
     eid=Integer(session[:employee_id])
    @leaveapplication = Leaveapplication.new
    @leavetypes=Leavetype.all
    @previousleaves=Leaveapplication.where("\"Employee_id\" =?",eid)
  end

  # GET /leaveapplications/1/edit
  def edit
    @leavetypes=Leavetype.all
  end

  # POST /leaveapplications
  # POST /leaveapplications.json
  def create
    @leaveapplication = Leaveapplication.new(leaveapplication_params)
    @leaveapplication.status=0
    @leaveapplication.Employee_id=session[:employee_id]
    respond_to do |format|
      if @leaveapplication.save
        format.html { redirect_to @leaveapplication, notice: 'Leaveapplication was successfully created.' }
        format.json { render :show, status: :created, location: @leaveapplication }
      else
        format.html { render :new }
        format.json { render json: @leaveapplication.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /leaveapplications/1
  # PATCH/PUT /leaveapplications/1.json
  def update
    respond_to do |format|
      if @leaveapplication.update(leaveapplication_params)
        format.html { redirect_to @leaveapplication, notice: 'Leaveapplication was successfully updated.' }
        format.json { render :show, status: :ok, location: @leaveapplication }
      else
        format.html { render :edit }
        format.json { render json: @leaveapplication.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /leaveapplications/1
  # DELETE /leaveapplications/1.json
  def destroy
    @leaveapplication.destroy
    respond_to do |format|
      format.html { redirect_to leaveapplications_url, notice: 'Leaveapplication was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_leaveapplication
      @leaveapplication = Leaveapplication.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def leaveapplication_params
      params.require(:leaveapplication).permit(:Fromdate, :Todate, :Description, :status, :Leavetype_id, :Employee)
    end
end
