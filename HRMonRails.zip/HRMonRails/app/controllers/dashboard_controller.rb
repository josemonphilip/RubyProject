class DashboardController < ApplicationController
  layout "admin"
 before_action :confirm_logged_in
  def index
      @leaveapplications = Leaveapplication.all
      
      @empCnt = []
      @empCnt << Employee.where(:employmenttype =>0).count
      @empCnt << Employee.where(:employmenttype =>1).count
  end
end
