class AccessController < ApplicationController
    layout "default"
    require 'login_logger'

  def login
  end
  def attempt_login
    if params[:user_name].present? && params[:password].present?
      found_user=User.where(:user_name => params[:user_name]).first
      if found_user
        authorized_user=found_user.authenticate(params[:password])
      end
    end
      if authorized_user
        session[:user_id]=authorized_user.id
        session[:username]=authorized_user.user_name.upcase
        session[:employee_id]=authorized_user.employee_id
        flash[:notice]="Welcome " + session[:username]
        
        # retrieve the instance/object of the MyLogger class
        logger = MyLogger.instance
        logger.logInformation("Login by: " + session[:username] +" Date and time :" + Time.new.to_s )

        
        
        found_user=User.where(:user_name => params[:user_name]).first
        if found_user.isAdmin
          redirect_to(:controller => 'dashboard')
        else
          redirect_to(:controller => 'mydashboard',:action=>'index')
        end
      else
          flash[:notice]="Wrong username or password . Please try again..!" 
        redirect_to(:action => 'login')
      end
  end
  
  def logout
    session[:user_id]=nil
    session[:username]=nil
    session[:employee_id]=nil
    flash[:notice]="Sign out successfully..! "
    redirect_to(:action => "login")
  end
  

end
