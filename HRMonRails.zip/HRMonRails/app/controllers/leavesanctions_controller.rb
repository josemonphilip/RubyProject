class LeavesanctionsController < ApplicationController
  layout "admin"
  before_action :confirm_logged_in
  def index
    @leaveapplications = Leaveapplication.where(:status => 0)    
  end
  
  def updatestatus
      @leaves=Leaveapplication.find(params[:id])
      @stat=params[:status]
      @leaves.status=@stat
      @leaves.save
      redirect_to :action => 'index'
  end
  
end
