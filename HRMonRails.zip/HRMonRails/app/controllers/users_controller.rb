class UsersController < ApplicationController
  layout "admin"
  
  def index
    @users=User.all
  end
  
  def new
    empid=User.pluck(:employee_id)
    if(empid.empty?)
      @employee=Employee.all
    else
      @employee=Employee.where('id not in (?)',empid)
    end
    @user=User.new
  end
  
   # POST /users
  def create
    empid=User.pluck(:employee_id)
    if(empid.empty?)
      @employee=Employee.where('id not in (?)',empid)
    else
      @employee=Employee.all
    end
    
    if User.where('user_name=?',user_params[:user_name]).blank?
      
      @user = User.new(user_params)
      respond_to do |format|
        if @user.save
          format.html { redirect_to '/users', notice: 'Employee was successfully created.' }
          format.json { render :show, status: :created, location: @user }
        else
          format.html { render :new }
          format.json { render json: @user.errors, status: :unprocessable_entity }
        end
      end
    else
       @user=User.new
       respond_to do |format|
        format.html { render :new }
        format.json { render json: @user.errors, status: :unprocessable_entity }
      end
    end
  end
  
  def user_params
      params.require(:user).permit(:employee_id,:user_name, :password, :password_confirmation,:isAdmin)
  end
end
