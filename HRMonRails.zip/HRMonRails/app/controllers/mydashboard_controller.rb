class MydashboardController < ApplicationController
  def index
    eid=Integer(session[:employee_id])
    @leaveapplications = Leaveapplication.where("\"Employee_id\" =?",eid)
    
    @draftleavecnt=[]
    @sanctionedleavecnt=[]
    @rejectedleavecnt=[]
    
    @draftleavecnt << Leaveapplication.where("\"Employee_id\" =? AND status=0",eid).count
    
    @sanctionedleavecnt << Leaveapplication.where("\"Employee_id\" =? AND status=1",eid).count
   
    @rejectedleavecnt << Leaveapplication.where("\"Employee_id\" =? AND status=2",eid).count
    
  end
end
