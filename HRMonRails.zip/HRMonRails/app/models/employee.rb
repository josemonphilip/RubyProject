class Employee < ActiveRecord::Base
  belongs_to :department
  has_one :employee
  
  
   def self.search(query)
    # where(:title, query) -> This would return an exact match of the query
    where("name like ?", "%#{query}%") 
   end
end
