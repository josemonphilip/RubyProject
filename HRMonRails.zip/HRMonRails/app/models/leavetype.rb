class Leavetype < ActiveRecord::Base
    has_many :Leaveapplication 
end
