class Leaveapplication < ActiveRecord::Base
  belongs_to :Leavetype
  belongs_to :Employee
end
