require 'test_helper'

class LeavesanctionControllerTest < ActionController::TestCase
  test "should get index" do
    get :index
    assert_response :success
  end

end
