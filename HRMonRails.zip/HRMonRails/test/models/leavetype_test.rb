require 'test_helper'

class LeavetypeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
